./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RHtsxup6uQvd1wp5DdFtAEXtUDdnHM92Yg.Rig1 -p d=16384s,hybrid --cpu 1
